import { BrowserRouter, Routes, Route } from 'react-router-dom';
import React from 'react'
import CountingFunction from './components/CountingFunction';
export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
         <Routes>
          <Route path="/count" element={<CountingFunction/>}/>
         </Routes>
      </BrowserRouter>
    </div>
  )
}
